package com.example.hw11Q15demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Hw11Q15demoApplication {

	public static void main(String[] args) {
		SpringApplication.run(Hw11Q15demoApplication.class, args);
	}

}
