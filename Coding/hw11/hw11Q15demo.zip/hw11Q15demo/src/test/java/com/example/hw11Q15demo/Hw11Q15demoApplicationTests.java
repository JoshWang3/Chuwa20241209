package com.example.hw11Q15demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Hw11Q15demoApplicationTests {

	@Test
	void contextLoads() {
	}

}
