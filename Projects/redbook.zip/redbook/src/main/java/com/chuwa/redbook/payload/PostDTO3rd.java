package com.chuwa.redbook.payload;

public class PostDTO3rd {
    private String title;
    private String description;
}
