package com.chuwa.mongo_blog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MongoBlogApplicationTests {

	@Test
	void contextLoads() {
	}

}
